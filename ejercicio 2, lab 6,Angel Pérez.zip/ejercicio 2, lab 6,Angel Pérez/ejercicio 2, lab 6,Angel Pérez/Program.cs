﻿using System;

namespace ejercicio_2__lab_6_Angel_Pérez
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2");

            int num1, num2, num3;

            Console.Write("Número 1: ");
            if (int.TryParse(Console.ReadLine(), out num1) == false || num1 <= 0)
            {
                Console.WriteLine("Error: el número ingresado no es válido.");
                return;
            }

            Console.Write("Número 2: ");
            if (int.TryParse(Console.ReadLine(), out num2) == false || num2 <= 0)
            {
                Console.WriteLine("Error: el número ingresado no es válido.");
                return;
            }

            Console.Write("Número 3: ");
            if (int.TryParse(Console.ReadLine(), out num3) == false || num3 <= 0)
            {
                Console.WriteLine("Error: el número ingresado no es válido.");
                return;
            }

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.WriteLine("El número mayor es: " + num1);
                }
                else
                {
                    Console.WriteLine("El número mayor es: " + num3);
                }
            }
            else
            {
                if (num2 > num3)
                {
                    Console.WriteLine("El número mayor es: " + num2);
                }
                else
                {
                    Console.WriteLine("El número mayor es: " + num3);
                }
            }

            Console.ReadLine();
        }
    }
}
