﻿using System;

namespace semana_6__Angel_Pérez
{
    namespace MesDelAnio
    {
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Ejercicio 1");

                Console.Write("Ingrese el número de mes: ");
                int numeroMes = int.Parse(Console.ReadLine());

                switch (numeroMes)
                {
                    case 1:
                        Console.WriteLine("MES: enero");
                        break;
                    case 2:
                        Console.WriteLine("MES: febrero");
                        break;
                    case 3:
                        Console.WriteLine("MES: marzo");
                        break;
                    case 4:
                        Console.WriteLine("MES: abril");
                        break;
                    case 5:
                        Console.WriteLine("MES: mayo");
                        break;
                    case 6:
                        Console.WriteLine("MES: junio");
                        break;
                    case 7:
                        Console.WriteLine("MES: julio");
                        break;
                    case 8:
                        Console.WriteLine("MES: agosto");
                        break;
                    case 9:
                        Console.WriteLine("MES: septiembre");
                        break;
                    case 10:
                        Console.WriteLine("MES: octubre");
                        break;
                    case 11:
                        Console.WriteLine("MES: noviembre");
                        break;
                    case 12:
                        Console.WriteLine("MES: diciembre");
                        break;
                    default:
                        Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 12");
                        break;
                }

                Console.ReadKey();
            }
        }
    }
}
